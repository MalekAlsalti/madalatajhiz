import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Download, FileText, Layers, Ruler, PaintRoller, Frame, ArrowRight } from 'lucide-react';
import SiteLayout, { Logo } from '@/components/SiteLayout';
import Reveal from '@/components/Reveal';
import CountUp from '@/components/CountUp';

const HERO = 'https://images.hostinger.com/5cc96d8f-47f6-4f80-9396-d26657622b51.png';
const INSTALL = 'https://images.hostinger.com/75681548-9b6b-41bc-8932-60b87d4188f2.png';
const PANELS = 'https://images.hostinger.com/ecbcccd1-0808-4ac1-81c7-752c28cab280.png';
const RECEPTION = 'https://images.hostinger.com/3fe7a314-6bdd-4fae-90d4-4df3575d57d8.png';

const services = [
    { icon: Layers, title: 'All Types of Flooring', text: 'Porcelain, ceramic, marble, vinyl, SPC, engineered wood and parquet — supplied and installed by our own crews.' },
    { icon: Ruler, title: 'Baseboards & Trims', text: 'MDF, PVC and aluminium skirting, profiles and edge trims cut and fitted to millimetre tolerance.' },
    { icon: PaintRoller, title: 'Wallpaper & Wall Panels', text: 'Imported wallpaper rolls, acoustic slat panels, WPC and 3D decorative panelling for homes and offices.' },
    { icon: Frame, title: 'Specialty Construction Artwork', text: 'Custom murals, feature walls, metal inlays and bespoke architectural detailing for signature spaces.' },
];

const downloads = [
    { title: 'Product Catalog 2025', meta: 'PDF · Flooring, panels, trims', note: 'Full range with finishes, sizes and technical data.' },
    { title: 'Project Portfolio', meta: 'PDF · Selected works', note: 'Residential, commercial and hospitality references.' },
    { title: 'Wallpaper & Panels Lookbook', meta: 'PDF · Collections', note: 'Patterns, textures and wall panel systems.' },
];

export default function HomePage() {
    return (
        <SiteLayout>
            <Helmet>
                <title>Mada Al Tajhiz | Flooring & Construction Materials Supply and Installation</title>
                <meta
                    name="description"
                    content="Mada Al Tajhiz supplies and installs all types of flooring, baseboards, wallpaper, wall panels, construction materials and specialty construction artwork in Saudi Arabia."
                />
            </Helmet>

            {/* HERO */}
            <section className="relative flex min-h-[100dvh] items-center overflow-hidden">
                <img src={HERO} alt="Flooring and wall panel showroom" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#123f52]/95 via-[#164e63]/85 to-[#164e63]/40" />
                <div className="relative mx-auto w-full max-w-[80rem] px-5 py-24">
                    <Reveal>
                        <div className="inline-flex items-center gap-2 rounded-sm border border-[#5fd3c4]/40 bg-white/5 px-4 py-2 text-xs font-semibold uppercase tracking-[0.22em] text-[#5fd3c4]">
                            Supply · Installation · Finishing
                        </div>
                    </Reveal>
                    <Reveal delay={0.1}>
                        <h1 className="mt-7 max-w-3xl text-4xl font-extrabold leading-[1.05] text-white sm:text-6xl lg:text-7xl">
                            Surfaces that finish
                            <span className="relative mx-3 inline-block text-[#5fd3c4]">
                                the build
                                <span className="absolute -bottom-2 left-0 h-1.5 w-full rounded-full bg-[#5fd3c4]/70" />
                            </span>
                            properly.
                        </h1>
                    </Reveal>
                    <Reveal delay={0.2}>
                        <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/80">
                            Mada Al Tajhiz delivers flooring, baseboards, wallpaper, wall panels, construction materials
                            and specialty artwork — sourced, measured and installed by one accountable team.
                        </p>
                    </Reveal>
                    <Reveal delay={0.3}>
                        <div className="mt-10 flex flex-wrap gap-4">
                            <a
                                href="#downloads"
                                className="inline-flex min-h-[48px] items-center gap-2 rounded-sm bg-[#2bb3a3] px-7 text-sm font-semibold uppercase tracking-wider text-[#0d3444] transition-transform hover:bg-[#5fd3c4] active:scale-[0.98]"
                            >
                                <Download className="h-4 w-4" /> Download Catalog
                            </a>
                            <Link
                                to="/contact"
                                className="inline-flex min-h-[48px] items-center gap-2 rounded-sm border border-white/40 px-7 text-sm font-semibold uppercase tracking-wider text-white transition-colors hover:bg-white/10"
                            >
                                Request a Quote <ArrowRight className="h-4 w-4" />
                            </Link>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* MARQUEE */}
            <div className="border-y border-[#164e63]/10 bg-[#f2f8f8] py-4">
                <div className="flex gap-10 overflow-hidden">
                    <div className="flex shrink-0 animate-[marquee_28s_linear_infinite] gap-10 whitespace-nowrap">
                        {[...Array(2)].map((_, i) => (
                            <span key={i} className="flex gap-10 text-sm font-semibold uppercase tracking-[0.2em] text-[#1f5d75]/70">
                                <span>Porcelain & Marble</span><span className="text-[#2bb3a3]">/</span>
                                <span>SPC & Vinyl</span><span className="text-[#2bb3a3]">/</span>
                                <span>Parquet</span><span className="text-[#2bb3a3]">/</span>
                                <span>Skirting & Trims</span><span className="text-[#2bb3a3]">/</span>
                                <span>Wallpaper</span><span className="text-[#2bb3a3]">/</span>
                                <span>Acoustic Panels</span><span className="text-[#2bb3a3]">/</span>
                                <span>Construction Artwork</span><span className="text-[#2bb3a3]">/</span>
                            </span>
                        ))}
                    </div>
                </div>
            </div>

            {/* SERVICES — service menu board, not card grid */}
            <section className="mx-auto max-w-[72rem] px-5 py-24">
                <Reveal>
                    <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#2bb3a3]">What we supply & install</p>
                    <h2 className="mt-4 max-w-2xl text-3xl font-bold leading-tight text-[#164e63] sm:text-4xl">
                        One supplier for every surface in the project
                    </h2>
                </Reveal>
                <div className="mt-12 divide-y divide-[#164e63]/12 border-t border-[#164e63]/12">
                    {services.map((s, i) => (
                        <Reveal key={s.title} delay={i * 0.06}>
                            <div className="group grid gap-4 py-8 md:grid-cols-[3rem_18rem_1fr] md:items-start">
                                <s.icon className="h-8 w-8 text-[#2bb3a3]" strokeWidth={1.6} />
                                <h3 className="text-xl font-bold text-[#164e63]">{s.title}</h3>
                                <p className="max-w-2xl leading-relaxed text-[#1f5d75]/80">{s.text}</p>
                            </div>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* SPLIT STORY */}
            <section className="bg-[#164e63] text-white">
                <div className="mx-auto grid max-w-[90rem] items-stretch lg:grid-cols-2">
                    <div className="order-2 px-5 py-20 lg:order-1 lg:px-16">
                        <Reveal>
                            <h2 className="text-3xl font-bold leading-tight sm:text-4xl">
                                Measured on site. Installed by our own crews.
                            </h2>
                            <p className="mt-6 max-w-xl leading-relaxed text-white/75">
                                We survey the substrate, calculate quantities, deliver on schedule and hand over a finished
                                surface. No split responsibility between the supplier and the installer.
                            </p>
                        </Reveal>
                        <div className="mt-12 grid grid-cols-3 gap-6">
                            {[
                                { v: 1400, s: '+', l: 'Projects delivered' },
                                { v: 18, s: ' yrs', l: 'In the trade' },
                                { v: 60, s: '+', l: 'Material lines' },
                            ].map((m) => (
                                <div key={m.l}>
                                    <p className="text-3xl font-extrabold text-[#5fd3c4]">
                                        <CountUp value={m.v} suffix={m.s} />
                                    </p>
                                    <p className="mt-2 text-xs uppercase tracking-[0.16em] text-white/60">{m.l}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="order-1 min-h-[22rem] lg:order-2">
                        <img src={INSTALL} alt="Installation crew fitting wood flooring" className="h-full w-full object-cover" />
                    </div>
                </div>
            </section>

            {/* PORTFOLIO ZIG-ZAG */}
            <section className="mx-auto max-w-[80rem] px-5 py-24">
                <Reveal>
                    <h2 className="text-3xl font-bold text-[#164e63] sm:text-4xl">Selected work</h2>
                </Reveal>
                <div className="mt-12 grid gap-8 md:grid-cols-2">
                    {[
                        { img: PANELS, t: 'Hospitality lobby panelling', l: 'Decorative wall panels & wallpaper' },
                        { img: RECEPTION, t: 'Corporate reception', l: 'Marble flooring, trims & feature artwork' },
                    ].map((p, i) => (
                        <Reveal key={p.t} delay={i * 0.1}>
                            <article className={`overflow-hidden ${i === 1 ? 'md:mt-14' : ''}`}>
                                <div className="overflow-hidden">
                                    <img
                                        src={p.img}
                                        alt={p.t}
                                        className="h-[22rem] w-full object-cover transition-transform duration-500 hover:scale-105"
                                    />
                                </div>
                                <p className="mt-5 text-xs font-semibold uppercase tracking-[0.2em] text-[#2bb3a3]">{p.l}</p>
                                <h3 className="mt-2 text-xl font-bold text-[#164e63]">{p.t}</h3>
                            </article>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* DOWNLOADS */}
            <section id="downloads" className="scroll-mt-24 bg-[#f2f8f8] py-24">
                <div className="mx-auto max-w-[72rem] px-5">
                    <Reveal>
                        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#2bb3a3]">Documents</p>
                        <h2 className="mt-4 text-3xl font-bold text-[#164e63] sm:text-4xl">Catalog & project portfolio</h2>
                        <p className="mt-5 max-w-2xl leading-relaxed text-[#1f5d75]/80">
                            Download our latest material catalog and completed project portfolio. New editions are published
                            here each season.
                        </p>
                    </Reveal>
                    <div className="mt-12 space-y-4">
                        {downloads.map((d, i) => (
                            <Reveal key={d.title} delay={i * 0.06}>
                                <div className="flex flex-wrap items-center gap-5 border border-[#164e63]/12 bg-white p-6">
                                    <FileText className="h-9 w-9 shrink-0 text-[#1f5d75]" strokeWidth={1.5} />
                                    <div className="min-w-[14rem] flex-1">
                                        <h3 className="text-lg font-bold text-[#164e63]">{d.title}</h3>
                                        <p className="text-sm text-[#1f5d75]/70">{d.note}</p>
                                        <p className="mt-1 text-xs uppercase tracking-[0.16em] text-[#2bb3a3]">{d.meta}</p>
                                    </div>
                                    <Link
                                        to="/contact"
                                        className="inline-flex min-h-[44px] items-center gap-2 rounded-sm bg-[#1f5d75] px-6 text-sm font-semibold text-white transition-colors hover:bg-[#2bb3a3] active:scale-[0.98]"
                                    >
                                        <Download className="h-4 w-4" /> Request file
                                    </Link>
                                </div>
                            </Reveal>
                        ))}
                    </div>
                    <p className="mt-6 text-sm text-[#1f5d75]/60">
                        Files are sent by our team on request while the download library is being finalised.
                    </p>
                </div>
            </section>

            {/* CTA */}
            <section className="mx-auto max-w-[72rem] px-5 pt-24">
                <div className="flex flex-col items-center gap-8 border border-[#164e63]/12 bg-white px-6 py-16 text-center">
                    <Logo className="h-14" />
                    <h2 className="max-w-2xl text-3xl font-bold text-[#164e63] sm:text-4xl">
                        Send us your drawings — we will return quantities and a fixed price
                    </h2>
                    <Link
                        to="/contact"
                        className="inline-flex min-h-[48px] items-center gap-2 rounded-sm bg-[#2bb3a3] px-8 text-sm font-semibold uppercase tracking-wider text-[#0d3444] transition-colors hover:bg-[#5fd3c4]"
                    >
                        Contact Mada Al Tajhiz <ArrowRight className="h-4 w-4" />
                    </Link>
                </div>
            </section>
        </SiteLayout>
    );
}
