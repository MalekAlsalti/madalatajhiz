import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import SiteLayout from '@/components/SiteLayout';
import Reveal from '@/components/Reveal';

const HERO = 'https://images.hostinger.com/3fe7a314-6bdd-4fae-90d4-4df3575d57d8.png';

const values = [
    { t: 'Single responsibility', d: 'Material supply and installation under one contract, so defects never fall between two vendors.' },
    { t: 'Verified materials', d: 'We stock and specify tested products with technical data sheets and warranty documentation.' },
    { t: 'Site discipline', d: 'Protected substrates, clean handover, agreed programme dates and daily progress reporting.' },
    { t: 'Detail obsession', d: 'Alignment, expansion gaps, trims and transitions are where finishing quality is actually judged.' },
];

const timeline = [
    { y: 'Supply', d: 'Flooring, baseboards, wallpaper, panels and general construction materials sourced from vetted mills and factories.' },
    { y: 'Survey', d: 'On-site measurement, substrate assessment, moisture checks and precise quantity take-off.' },
    { y: 'Install', d: 'Our own trained crews lay, fit and finish — no subcontracted quality risk.' },
    { y: 'Handover', d: 'Cleaning, protection, snag-list closure and maintenance guidance for the client team.' },
];

export default function AboutPage() {
    return (
        <SiteLayout>
            <Helmet>
                <title>About Mada Al Tajhiz | Flooring & Finishing Contractors</title>
                <meta
                    name="description"
                    content="Learn about Mada Al Tajhiz, a Saudi supplier and installer of flooring, baseboards, wallpaper, wall panels, construction materials and specialty construction artwork."
                />
            </Helmet>

            <section className="relative overflow-hidden bg-[#164e63]">
                <img src={HERO} alt="Finished reception interior" className="absolute inset-0 h-full w-full object-cover opacity-30" />
                <div className="relative mx-auto max-w-[72rem] px-5 py-28">
                    <Reveal>
                        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#5fd3c4]">About us</p>
                        <h1 className="mt-5 max-w-3xl text-4xl font-extrabold leading-[1.1] text-white sm:text-5xl">
                            A finishing contractor built around materials we actually stand behind
                        </h1>
                    </Reveal>
                </div>
            </section>

            <section className="mx-auto grid max-w-[72rem] gap-14 px-5 py-24 lg:grid-cols-[1.2fr_1fr]">
                <Reveal>
                    <div className="space-y-6 text-lg leading-relaxed text-[#1f5d75]/85">
                        <p>
                            Mada Al Tajhiz supplies and installs the surfaces that decide how a building feels: floors,
                            skirting and trims, wallpaper, decorative wall panels, general construction materials and
                            specialty construction artwork.
                        </p>
                        <p>
                            We work with contractors, interior designers, developers and private clients across the Kingdom
                            — from single villas and clinics to hotel lobbies and corporate fit-outs. Because we hold the
                            material and the trade crew, our programme dates and our quality standard are the same promise.
                        </p>
                    </div>
                </Reveal>
                <Reveal delay={0.1}>
                    <ul className="space-y-6 border-l-2 border-[#2bb3a3] pl-6">
                        {values.map((v) => (
                            <li key={v.t}>
                                <p className="flex items-center gap-2 font-bold text-[#164e63]">
                                    <CheckCircle2 className="h-5 w-5 text-[#2bb3a3]" /> {v.t}
                                </p>
                                <p className="mt-1 text-sm leading-relaxed text-[#1f5d75]/75">{v.d}</p>
                            </li>
                        ))}
                    </ul>
                </Reveal>
            </section>

            <section className="bg-[#f2f8f8] py-24">
                <div className="mx-auto max-w-[72rem] px-5">
                    <Reveal>
                        <h2 className="text-3xl font-bold text-[#164e63] sm:text-4xl">How a project runs</h2>
                    </Reveal>
                    <div className="mt-12 grid gap-px bg-[#164e63]/12 md:grid-cols-4">
                        {timeline.map((t, i) => (
                            <Reveal key={t.y} delay={i * 0.08}>
                                <div className="h-full bg-[#f2f8f8] p-7">
                                    <span className="text-4xl font-extrabold text-[#5fd3c4]">0{i + 1}</span>
                                    <h3 className="mt-3 text-lg font-bold text-[#164e63]">{t.y}</h3>
                                    <p className="mt-2 text-sm leading-relaxed text-[#1f5d75]/75">{t.d}</p>
                                </div>
                            </Reveal>
                        ))}
                    </div>
                    <Link
                        to="/contact"
                        className="mt-12 inline-flex min-h-[48px] items-center rounded-sm bg-[#1f5d75] px-8 text-sm font-semibold uppercase tracking-wider text-white transition-colors hover:bg-[#2bb3a3]"
                    >
                        Talk to our team
                    </Link>
                </div>
            </section>
        </SiteLayout>
    );
}
