import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Phone, Mail, MapPin, Clock, Send, Loader2 } from 'lucide-react';
import SiteLayout from '@/components/SiteLayout';
import Reveal from '@/components/Reveal';
import { useToast } from '@/hooks/use-toast';
import { Toaster } from '@/components/ui/toaster';

const field =
    'w-full rounded-sm border border-[#164e63]/20 bg-white px-4 py-3 text-[#164e63] outline-none transition-colors placeholder:text-[#1f5d75]/40 focus:border-[#2bb3a3]';

export default function ContactPage() {
    const { toast } = useToast();
    const [sending, setSending] = useState(false);
    const [form, setForm] = useState({ name: '', email: '', phone: '', scope: '', message: '' });
    const [errors, setErrors] = useState({});

    const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

    const submit = (e) => {
        e.preventDefault();
        const next = {};
        if (!form.name.trim()) next.name = 'Please enter your name';
        if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = 'Please enter a valid email';
        if (!form.message.trim()) next.message = 'Tell us briefly what you need';
        setErrors(next);
        if (Object.keys(next).length) return;
        setSending(true);
        setTimeout(() => {
            setSending(false);
            setForm({ name: '', email: '', phone: '', scope: '', message: '' });
            toast({
                title: 'Enquiry ready to send',
                description: 'Message noted. Our team will follow up by phone or email.',
            });
        }, 700);
    };

    return (
        <SiteLayout>
            <Helmet>
                <title>Contact Mada Al Tajhiz | Flooring & Materials Enquiries</title>
                <meta
                    name="description"
                    content="Contact Mada Al Tajhiz for flooring, baseboards, wallpaper, wall panels and construction materials supply and installation quotations in Saudi Arabia."
                />
            </Helmet>

            <section className="bg-[#164e63] px-5 py-24">
                <div className="mx-auto max-w-[72rem]">
                    <Reveal>
                        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#5fd3c4]">Contact</p>
                        <h1 className="mt-5 max-w-2xl text-4xl font-extrabold leading-tight text-white sm:text-5xl">
                            Send your scope, drawings or material list
                        </h1>
                    </Reveal>
                </div>
            </section>

            <section className="mx-auto grid max-w-[72rem] gap-14 px-5 py-20 lg:grid-cols-[1fr_1.1fr]">
                <Reveal>
                    <div className="space-y-8">
                        {[
                            { i: Phone, t: 'Phone', v: '+966 50 000 0000', href: 'tel:+966500000000' },
                            { i: Mail, t: 'Email', v: 'info@madaaltajhiz.com', href: 'mailto:info@madaaltajhiz.com' },
                            { i: MapPin, t: 'Office', v: 'Riyadh, Saudi Arabia' },
                            { i: Clock, t: 'Hours', v: 'Sun – Thu, 9:00 – 18:00' },
                        ].map((c) => (
                            <div key={c.t} className="flex gap-4 border-b border-[#164e63]/10 pb-6">
                                <c.i className="mt-1 h-5 w-5 shrink-0 text-[#2bb3a3]" />
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#1f5d75]/60">{c.t}</p>
                                    {c.href ? (
                                        <a href={c.href} className="text-lg font-semibold text-[#164e63] hover:text-[#2bb3a3]">
                                            {c.v}
                                        </a>
                                    ) : (
                                        <p className="text-lg font-semibold text-[#164e63]">{c.v}</p>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </Reveal>

                <Reveal delay={0.1}>
                    <form onSubmit={submit} className="border border-[#164e63]/12 bg-[#f2f8f8] p-7 sm:p-9">
                        <div className="grid gap-5 sm:grid-cols-2">
                            <div className="flex flex-col gap-2">
                                <label htmlFor="name" className="text-sm font-semibold text-[#164e63]">Name</label>
                                <input id="name" className={field} value={form.name} onChange={set('name')} placeholder="Full name" />
                                {errors.name && <span className="text-xs text-red-600">{errors.name}</span>}
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="text-sm font-semibold text-[#164e63]">Email</label>
                                <input id="email" className={field} value={form.email} onChange={set('email')} placeholder="you@company.com" />
                                {errors.email && <span className="text-xs text-red-600">{errors.email}</span>}
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="phone" className="text-sm font-semibold text-[#164e63]">Phone</label>
                                <input id="phone" className={field} value={form.phone} onChange={set('phone')} placeholder="+966 …" />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="scope" className="text-sm font-semibold text-[#164e63]">Scope</label>
                                <input id="scope" className={field} value={form.scope} onChange={set('scope')} placeholder="Flooring, panels, wallpaper…" />
                            </div>
                        </div>
                        <div className="mt-5 flex flex-col gap-2">
                            <label htmlFor="message" className="text-sm font-semibold text-[#164e63]">Project details</label>
                            <textarea id="message" rows={5} className={field} value={form.message} onChange={set('message')} placeholder="Location, area in m², required finish and timeline" />
                            {errors.message && <span className="text-xs text-red-600">{errors.message}</span>}
                        </div>
                        <button
                            type="submit"
                            disabled={sending}
                            className="mt-7 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-sm bg-[#1f5d75] px-8 text-sm font-semibold uppercase tracking-wider text-white transition-colors hover:bg-[#2bb3a3] active:scale-[0.99] disabled:opacity-70 sm:w-auto"
                        >
                            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                            {sending ? 'Sending' : 'Send enquiry'}
                        </button>
                    </form>
                </Reveal>
            </section>
            <Toaster />
        </SiteLayout>
    );
}
