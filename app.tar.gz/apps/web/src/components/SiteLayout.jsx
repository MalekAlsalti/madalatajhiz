import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, X, Phone, Mail, MapPin } from 'lucide-react';

const LOGO = 'https://horizons-cdn.hostinger.com/76773d75-84d9-40ff-96d1-197d43e91cbf/04e6b003b8db06fd234dac407dfbf3c5.jpg';

const nav = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/contact', label: 'Contact' },
];

export function Logo({ className = 'h-12', variant = 'light' }) {
    // JPG has a solid white matte — multiply blends it into light chrome;
    // on dark surfaces we keep a soft white plate so the mark stays crisp.
    if (variant === 'dark') {
        return (
            <span
                className="inline-flex items-center justify-center rounded-md bg-white px-3.5 py-2 shadow-[0_8px_24px_-12px_rgba(0,0,0,0.45)] ring-1 ring-white/60"
            >
                <img
                    src={LOGO}
                    alt="Mada Al Tajhiz"
                    className={`${className} w-auto max-w-[min(100%,14rem)] object-contain object-left`}
                    decoding="async"
                />
            </span>
        );
    }
    return (
        <img
            src={LOGO}
            alt="Mada Al Tajhiz"
            className={`${className} w-auto max-w-[min(100%,16rem)] object-contain object-left mix-blend-multiply`}
            decoding="async"
        />
    );
}

export default function SiteLayout({ children }) {
    const [open, setOpen] = useState(false);
    return (
        <div className="min-h-screen bg-white text-[#164e63]">
            <header className="sticky top-0 z-40 border-b border-[#164e63]/10 bg-white/90 backdrop-blur-md">
                <div className="mx-auto flex max-w-[80rem] items-center justify-between gap-4 px-5 py-2.5 sm:py-3">
                    <Link
                        to="/"
                        className="group flex min-h-[44px] items-center rounded-sm outline-none ring-[#2bb3a3]/0 transition-[box-shadow] focus-visible:ring-2 focus-visible:ring-[#2bb3a3]/50"
                        aria-label="Mada Al Tajhiz home"
                    >
                        <Logo className="h-10 transition-opacity duration-200 group-hover:opacity-90 sm:h-12 md:h-[3.25rem]" />
                    </Link>
                    <nav className="hidden items-center gap-8 md:flex">
                        {nav.map((n) => (
                            <NavLink
                                key={n.to}
                                to={n.to}
                                className={({ isActive }) =>
                                    `text-sm font-semibold uppercase tracking-[0.14em] transition-colors ${isActive ? 'text-[#2bb3a3]' : 'text-[#1f5d75] hover:text-[#2bb3a3]'}`
                                }
                            >
                                {n.label}
                            </NavLink>
                        ))}
                        <a
                            href="tel:+966500000000"
                            className="rounded-sm bg-[#1f5d75] px-5 py-3 text-sm font-semibold text-white transition-transform hover:bg-[#2bb3a3] active:scale-[0.98]"
                        >
                            Request a Quote
                        </a>
                    </nav>
                    <button
                        type="button"
                        aria-label="Toggle menu"
                        onClick={() => setOpen((v) => !v)}
                        className="p-2 md:hidden"
                    >
                        {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                    </button>
                </div>
                {open && (
                    <div className="border-t border-[#164e63]/10 bg-white md:hidden">
                        {nav.map((n) => (
                            <Link
                                key={n.to}
                                to={n.to}
                                onClick={() => setOpen(false)}
                                className="block px-6 py-4 text-base font-semibold text-[#1f5d75]"
                            >
                                {n.label}
                            </Link>
                        ))}
                        <a href="tel:+966500000000" className="block bg-[#1f5d75] px-6 py-4 text-base font-semibold text-white">
                            Call us now
                        </a>
                    </div>
                )}
            </header>

            <main>{children}</main>

            <footer className="mt-24 bg-[#164e63] text-white/80">
                <div className="mx-auto grid max-w-[80rem] gap-10 px-5 py-14 md:grid-cols-3">
                    <div>
                        <Logo className="h-11 sm:h-12" variant="dark" />
                        <p className="mt-6 max-w-sm text-sm leading-relaxed text-white/75">
                            Supply and installation of flooring, baseboards, wallpaper, wall panels and specialty
                            construction artwork across the Kingdom.
                        </p>
                    </div>
                    <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#5fd3c4]">Navigate</p>
                        <ul className="mt-4 space-y-2 text-sm">
                            {nav.map((n) => (
                                <li key={n.to}>
                                    <Link to={n.to} className="hover:text-white">{n.label}</Link>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#5fd3c4]">Contact</p>
                        <ul className="mt-4 space-y-3 text-sm">
                            <li className="flex items-center gap-3"><Phone className="h-4 w-4 text-[#5fd3c4]" /> +966 50 000 0000</li>
                            <li className="flex items-center gap-3"><Mail className="h-4 w-4 text-[#5fd3c4]" /> info@madaaltajhiz.com</li>
                            <li className="flex items-center gap-3"><MapPin className="h-4 w-4 text-[#5fd3c4]" /> Riyadh, Saudi Arabia</li>
                        </ul>
                    </div>
                </div>
                <div className="border-t border-white/10 px-5 py-5 text-center text-xs">
                    © {new Date().getFullYear()} Mada Al Tajhiz. All rights reserved.
                </div>
            </footer>
        </div>
    );
}
